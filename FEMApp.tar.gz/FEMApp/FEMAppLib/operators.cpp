#include "operators.h"

/*
mvector& operator=( mvector &mv, const ExpressionVector &ev )
{
    mv.SetDim( ev.GetList().size() );
    unsigned k;
    for (k=0; k<mv.GetDim(); k++) mv[k]=ev.GetList()[k]->Compute();
    return mv;
}
*/
