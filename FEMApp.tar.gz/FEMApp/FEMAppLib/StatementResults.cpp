#include "StatementResults.h"

CStatementResults::CStatementResults( CFEMProject &f ):FP( f )
{
}

CStatementResults::~CStatementResults(void)
{
}

void CStatementResults::Execute( istream &i )
{

}