
      real*8          dm
      integer            n,ma,mct,iel,nel,pstyp
      common /eldata/ dm,n,ma,mct,iel,nel,pstyp
