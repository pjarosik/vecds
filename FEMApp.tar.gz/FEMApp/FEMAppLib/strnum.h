
      integer         istv, iste, istp
      common /strnum/ istv, iste, istp
