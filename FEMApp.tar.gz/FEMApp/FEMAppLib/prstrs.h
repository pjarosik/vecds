
      integer*8       nph,ner                                      ! int8
      real*8                  erav,j_int   ,jshft
      common /prstrs/ nph,ner,erav,j_int(3),jshft
