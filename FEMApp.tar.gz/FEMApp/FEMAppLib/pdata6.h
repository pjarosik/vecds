
      integer         inord    ,ipord
      common /pdata6/ inord(50),ipord(50,50)
