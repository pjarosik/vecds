
      real*8             one2,one3,one6,one9,one12,one36
      common /pconstant/ one2,one3,one6,one9,one12,one36

      real*8             two3,four3,four9
      common /pconstant/ two3,four3,four9
      
      real*8             pi,pi23,sqrt2,sqt13,sqt23,sqtp6,sqt48
      common /pconstant/ pi,pi23,sqrt2,sqt13,sqt23,sqtp6,sqt48

      real*8             five9,eight9,thty29
      common /pconstant/ five9,eight9,thty29
