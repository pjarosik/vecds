#ifndef OPERATORS_H
#define OPERATORS_H

#include <vector>
#include "../MathLib/matrix.h"
#include "../LangLib/statdef.h"

//mvector& operator=( mvector &mv, const ExpressionVector &ev );


#endif // OPERATORS_H
