
      integer         ior,iow,ilg
      common /iofile/ ior,iow,ilg
