
      real*8          epl
      integer                  iepl,       neplts
      common /ptdat6/ epl(200),iepl(2,200),neplts
