
      real*8          bpr   ,ctan   ,psil
      common /eltran/ bpr(3),ctan(3),psil
