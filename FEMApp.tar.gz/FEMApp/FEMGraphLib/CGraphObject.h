#ifndef CGRAPHOBJECT_H
#define CGRAPHOBJECT_H

class CGraphObject
{
public:
    CGraphObject();
};

#endif // CGRAPHOBJECT_H
