#include "GraphEdge.h"

CGraphEdge::CGraphEdge()
{
}
