#include "GraphObject.h"

CGraphObject::CGraphObject():border(false)
{

}
