#include "GraphFace.h"

CGraphFace::CGraphFace()
{
}
