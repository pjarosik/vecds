#include "Atom.h"

CAtom::CAtom( const AtomStruct& a, const mvector &c ):as(a),x(c)
{
    //ctor
}

CAtom::~CAtom()
{
    //dtor
}
