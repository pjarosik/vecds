#include "DOF_Fiz.h"
#include "DOF_types.h"

CDOF_Fiz::CDOF_Fiz():CDOF(DOF_FIZ)
{
}


CDOF_Fiz::~CDOF_Fiz(void)
{
}
