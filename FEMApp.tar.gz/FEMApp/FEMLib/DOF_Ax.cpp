
#include "DOF_Ax.h"
#include "DOF_types.h"

CDOF_Ax::CDOF_Ax(void):CDOF( DOF_AX )
{
}

CDOF_Ax::~CDOF_Ax(void)
{
}
