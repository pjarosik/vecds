#include "DOF_D.h"

CDOF_D::CDOF_D(void):CDOF(DOF_D)
{
}

CDOF_D::~CDOF_D(void)
{
}
