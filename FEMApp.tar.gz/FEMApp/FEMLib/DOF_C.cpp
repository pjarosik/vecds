#include "DOF_C.h"

CDOF_C::CDOF_C(void):CDOF(DOF_C)
{
}

CDOF_C::~CDOF_C(void)
{
}
