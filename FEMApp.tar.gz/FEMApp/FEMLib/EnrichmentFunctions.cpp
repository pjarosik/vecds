
#include "EnrichmentFunctions.h"

CEnrichmentFunctions::CEnrichmentFunctions(void)
{
}

CEnrichmentFunctions::~CEnrichmentFunctions(void)
{
}
