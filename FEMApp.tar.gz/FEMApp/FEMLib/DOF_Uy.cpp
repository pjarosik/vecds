
#include "DOF_Uy.h"
#include "DOF_types.h"

CDOF_Uy::CDOF_Uy(void):CDOF(DOF_UY)
{
}

CDOF_Uy::~CDOF_Uy(void)
{
}
