
#include "DOF_Ay.h"
#include "DOF_types.h"

CDOF_Ay::CDOF_Ay(void):CDOF(DOF_AY)
{
}

CDOF_Ay::~CDOF_Ay(void)
{
}
