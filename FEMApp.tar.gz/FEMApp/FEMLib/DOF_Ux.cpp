
#include "DOF_Ux.h"
#include "DOF_types.h"

CDOF_Ux::CDOF_Ux( void ):CDOF( DOF_UX )
{
}

CDOF_Ux::~CDOF_Ux( void )
{
}
