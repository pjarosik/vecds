#include "DOF_Fix.h"
#include "DOF_types.h"


CDOF_Fix::CDOF_Fix():CDOF(DOF_FIX)
{
}


CDOF_Fix::~CDOF_Fix(void)
{
}
