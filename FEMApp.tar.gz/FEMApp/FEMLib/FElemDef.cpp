#include "FElemDef.h"


CFElemDef::CFElemDef(void)
{
}


CFElemDef::~CFElemDef(void)
{
}
