#include "DOF_Fiy.h"
#include "DOF_types.h"


CDOF_Fiy::CDOF_Fiy():CDOF(DOF_FIX)
{
}


CDOF_Fiy::~CDOF_Fiy(void)
{
}
