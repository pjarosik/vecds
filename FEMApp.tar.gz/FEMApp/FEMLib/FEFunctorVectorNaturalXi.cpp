
#include "FEFunctorVectorNaturalXi.h"

CFEFunctorVectorNaturalXi::CFEFunctorVectorNaturalXi(void):CFEFunctorVector("CFEFunctorVectorNaturalXi")
{
}

CFEFunctorVectorNaturalXi::~CFEFunctorVectorNaturalXi(void)
{
}
