#include "DOF_T.h"
#include "DOF_types.h"

CDOF_T::CDOF_T(void):CDOF(DOF_T)
{
}

CDOF_T::~CDOF_T(void)
{
}
