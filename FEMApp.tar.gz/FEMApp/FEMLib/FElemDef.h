#pragma once

class CFElemDef
{
public:
	CFElemDef(void);
	~CFElemDef(void);
};

