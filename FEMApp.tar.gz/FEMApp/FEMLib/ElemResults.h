#ifndef ELEMRESULTS_H
#define ELEMRESULTS_H

class CElemResults
{
public:
    CElemResults();
};

#endif // ELEMRESULTS_H
