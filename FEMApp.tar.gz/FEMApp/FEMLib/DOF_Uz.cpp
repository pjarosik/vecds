
#include "DOF_Uz.h"
#include "DOF_types.h"

CDOF_Uz::CDOF_Uz(void):CDOF(DOF_UZ)
{
}

CDOF_Uz::~CDOF_Uz(void)
{
}
