
#include "FEFunctorMatrixColDOF.h"

CFEFunctorMatrixColDOF::CFEFunctorMatrixColDOF( const string &nm, bool cd):CFEFunctorMatrix(nm)
{
}

CFEFunctorMatrixColDOF::~CFEFunctorMatrixColDOF(void)
{
}


