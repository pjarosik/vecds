
#include "DOF_Bx.h"
#include "DOF_types.h"

CDOF_Bx::CDOF_Bx( unsigned st ):CDOF( DOF_BX + st )
{
}

CDOF_Bx::~CDOF_Bx(void)
{
}
