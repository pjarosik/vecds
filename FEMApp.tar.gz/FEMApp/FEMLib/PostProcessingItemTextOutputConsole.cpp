#include "PostProcessingItemTextOutputConsole.h"

CPostProcessingItemTextOutputConsole::CPostProcessingItemTextOutputConsole( const OutputDef &od ):CPostProcessingItemTextOutput( od )
{
}
