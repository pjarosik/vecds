
#include "IntegrationPoints.h"

CIntegrationPoints::CIntegrationPoints( int t, int dm, int dg ): dim( dm ), degree( dg ),type( t )
{
}

CIntegrationPoints::~CIntegrationPoints(void)
{
}
