#include "ElemResults.h"

CElemResults::CElemResults()
{
}
