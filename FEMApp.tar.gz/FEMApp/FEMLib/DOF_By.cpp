
#include "DOF_By.h"
#include "DOF_types.h"

CDOF_By::CDOF_By(unsigned st):CDOF(DOF_BY+st)
{
}

CDOF_By::~CDOF_By(void)
{
}
