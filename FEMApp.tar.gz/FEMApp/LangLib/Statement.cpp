
#include "Statement.h"


CStatement::CStatement( ) 
{
}

CStatement::~CStatement(void)
{
}
