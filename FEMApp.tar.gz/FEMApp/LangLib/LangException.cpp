
#include "LangException.h"



CLangException::~CLangException(void)
{
}
