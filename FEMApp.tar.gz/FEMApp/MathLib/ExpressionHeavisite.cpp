#include "ExpressionHeavisite.h"


CExpressionHeavisite::CExpressionHeavisite(CExpression *ex)
{
	expr.push_back( ex );
}


CExpressionHeavisite::~CExpressionHeavisite(void)
{
}
