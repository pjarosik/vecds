#include "ExpressionPI.h"


CExpressionPI::CExpressionPI(void)
{
}


CExpressionPI::~CExpressionPI(void)
{
}
