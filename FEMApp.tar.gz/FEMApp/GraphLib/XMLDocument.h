#pragma once
#include "textdocument.h"

class CXMLDocument :
	public CTextDocument
{
public:
	CXMLDocument(void);
public:
	virtual ~CXMLDocument(void);
};
