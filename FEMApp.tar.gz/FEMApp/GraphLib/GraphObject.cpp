
#include "GraphObject.h"

CGraphObject::CGraphObject(void)
{
}

CGraphObject::~CGraphObject(void)
{
}
