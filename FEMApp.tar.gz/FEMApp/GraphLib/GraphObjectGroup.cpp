
#include "GraphObjectGroup.h"

CGraphObjectGroup::CGraphObjectGroup(void)
{
}

CGraphObjectGroup::~CGraphObjectGroup(void)
{
}
